//
//  main.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var Santosh = Customer()
Santosh.customerID = "C101"
//Santosh.customerName = "Santosh"
print(Santosh.displayData())

var Param = Customer(customerID: "C102", customerName: "Paramjeet", email: "param@mad.com",
    address: "114 Michigan Ave. Brampton", creditCardInfo: "4520-0100-1234-5678",
    shippingInfo: "Ship to lambton college between 08:00 AM to 12:00 PM")
print(Param.displayData())

var Saloni = Customer()
Saloni.registerUser()
print(Saloni.displayData())

Saloni.CustomerName = "Sallu"
Saloni.ShippingInfo = "Deliver between 10AM to 12PM"
print(Saloni.displayData())

Santosh.CustomerName = "Santosh"
Santosh.Email = "Santosh@mad.com"
Santosh.Address = "54 Marjary Ave. Downtown. Toronto"
Santosh.CreditCardInfo = "4530-3421-7823-0023"
Santosh.ShippingInfo = "Deliver at Papa John's at 03PM"
print(Santosh.displayData())
