//
//  AirlineDetails.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class AirlineDetails{
    var airlinesID : Int?
    var enquiryID : Int?
    private var airlinesDescription : String?
    private var airlinesType : String?
    private var enquiryType : String?
    private var enquiryTitle : String?
    private var enquiryDescription : String?
    private var enquiryDate : Date?
    
    
    var AirlinesDescription : String?{
        get{
            return self.airlinesDescription
        }
        set{
            self.airlinesDescription = newValue
        }
    }
    
    var AirlinesType : String?{
        get{
            return self.airlinesType
        }
        set{
            self.airlinesType = newValue
        }
    }
    
    var EnquiryType : String?{
        get{
            return self.enquiryType
        }
        set{
            self.enquiryType = newValue
        }
    }
    var EnquiryTitle : String?{
        get{
            return self.enquiryTitle
        }
        set{
            self.enquiryTitle = newValue
        }
    }
    var EnquiryDescription : String?{
        get{
            return self.enquiryDescription
        }
        set{
            self.enquiryDescription = newValue
        }
    }
    var EnquiryDate : Date?{
        get{
            return self.enquiryDate
        }
        set{
            self.enquiryDate = newValue
        }
    }
    
    init(){
        self.airlinesID = 0
        self.enquiryID = 0
        self.airlinesDescription = ""
        self.airlinesType = ""
        self.enquiryType = ""
        self.enquiryTitle = ""
        self.enquiryDescription = ""
        self.enquiryDate =
    }
    
    init(airlinesID: Int, enquiryID: Int, airlinesDescription: String, airlinesType: String, enquiryType: String, enquiryTitle: String, enquiryDescription: String, enquiryDate: Date){
        
        self.airlinesID = airlinesID
        self.enquiryID = enquiryID
        self.airlinesDescription = airlinesDescription
        self.airlinesType = airlinesType
        self.enquiryType = enquiryType
        self.enquiryTitle = enquiryTitle
        self.enquiryDescription = enquiryDescription
        self.enquiryDate = enquiryDate
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.airlinesID != nil{
            returnData += "Airlines ID : " + self.airlinesID!
        }
        if self.enquiryID != nil{
            returnData += "Enquiry ID : " + self.enquiryID!
        }
        if self.airlinesDescription != nil{
            returnData += "\n Airlines Description : " + self.airlinesDescription!
        }
        if self.airlinesType != nil{
            returnData += "\n Airlines Type : " + self.airlinesType!
        }
        if self.enquiryType != nil{
            returnData += "\n Enquiry Type : " + self.enquiryType!
        }
        if self.enquiryTitle != nil{
            returnData += "\n Enquiry Title : " + self.enquiryTitle!
        }
        if self.enquiryDescription != nil{
            returnData += "\n Enquiry Description : " + self.enquiryDescription!
        }
        if self.enquiryDate != nil{
            returnData += "Enquiry Date : " + self.enquiryDate!
        }
        return returnData
    }
    
    func registerUser(){
        print("Enter Airlines Id : ")
        self.airlinesID = readLine()!
        print("Enter Enquiry Id : ")
        self.enquiryID = readLine()!
        print("Enter Airlines Description : ")
        self.airlinesDescription = readLine()!
        print("Enter Airlines Type : ")
        self.airlinesType = readLine()!
        print("Enter Enquiry Type : ")
        self.enquiryType = readLine()!
        print("Enter Enquiry Title : ")
        self.enquiryTitle = readLine()!
        print("Enter Enquiry Description : ")
        self.enquiryDescription = readLine()!
        print("Enter Enquiry Date : ")
        self.enquiryDate = readLine()!    }
    
}


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
