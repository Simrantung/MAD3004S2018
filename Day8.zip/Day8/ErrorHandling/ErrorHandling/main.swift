//
//  main.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var request1 = RequestLimitIncrease()

//do{
//try request1.increaseLimit(accountNo: "S1300")
//}catch limitIncreaseError.ineligible{
//    print("You must have account with our bank.")
//}catch limitIncreaseError.noSavingAccount{
//    print("Sorry..Limit increase is provided only to the Saving account holders.")
//}catch limitIncreaseError.insufficientBalance{
//    print("Minimum $5000 balance is required for credit limt increase.")
//}catch{
//    print("Something unexpected happen.. Sorry for the service disruption")
//}

do{
    try request1.increaseLimit(accountNo: "S1300")
}catch is limitIncreaseError{
    print("You do not match any of the following criteria for credit limit increase")
    print("1. No account with our bank \n2. No Saving account \n3 Insufficient balance in savings account (minimum $5000)")
}
//catch is transactionError{
//
//}

var s1 = Student()
s1.name = "HK"
//Student.accNo = 123456
s1.display()

print("account no : \(Student.accNo)")

var s2 = Student()
print("Student count : \(Student.getStudentCount())")

var s3 = PartTime()
s3.display()
print(PartTime.getStudentCount())

var s4 = Student()
s4.name = "Gurjot"
s4.display()

s4 = PartTime()
s4.display()

s2 = s1

//reference
//s1 = s2 as! PartTime
//s1.display()









