//
//  Student.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

//final class Student{
//open class Student{
//public class Student{
//private class Student{
//fileprivate class Student{
class Student{
    var name: String?
    static var accNo: Int?
    static var countSt = 0
    
    init(){
        self.name = "Unknown"
        Student.accNo = 123456
        Student.countSt += 1
    }
    
    func display(){
        print("Student name \(self.name ?? "Unknown")")
        print("fees account no \(Student.accNo ?? 000)")
    }
    
    static func getStudentCount() -> Int{
        var i = accNo
       // var j = name //name caanot be used on type student
        return countSt
    }
}

class PartTime : Student{
    var hours: Int?
    
    override init(){
        super.init()
        self.hours = 10
    }
    
    override func display(){
        print("Hours : \(self.hours ?? 40)")
    }
}
